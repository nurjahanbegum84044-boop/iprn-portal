# TaskHub – launch guide

No dependencies. Needs only Node 18 or newer.

## 1. Test on your computer
    ADMIN_USER=yourname ADMIN_PASS='your-strong-password' node server.js
Open http://localhost:3000. Owner login is the "Admin" link in the footer.

## 2. Put it online (Render example)
1. Upload this folder to a private GitHub repository.
2. Render > New > Web Service > choose the repo. Start command: `node server.js`.
3. Environment variables:
   - ADMIN_USER = your admin username
   - ADMIN_PASS = your admin password (choose a NEW strong one, never put it in code)
   - DATA_DIR = /data
4. Add a Persistent Disk mounted at /data. Without a disk, all users, balances and images are erased on every restart or deploy. Free instances have no disk, so use a paid instance (or any VPS) for real money.
5. Add your own domain under Settings > Custom Domains (HTTPS is automatic).

## 3. Before real users
- Admin > Settings: site name, currency, minimum withdrawal, platform fee, and the bank details advertisers pay to.
- Back up the /data folder regularly (db.json and the img folder).
- Money flow: advertiser pays you by bank transfer and sends a reference, you check your bank and press Credit. Worker requests a withdrawal, you pay from your bank and press Paid (Reject refunds the worker).
- Ask a lawyer or accountant about running a payments platform in your country.
